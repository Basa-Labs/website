<div class="lqd-preloader-wrap lqd-preloader-spinner-classsical" data-preloader-options='{ "animationType": "fade" }'>
	<div class="lqd-preloader-inner">

		<div class="lqd-preloader-spc-el"></div>

	</div>
</div>